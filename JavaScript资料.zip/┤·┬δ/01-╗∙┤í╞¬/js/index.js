// 该页面中的元素都加载完毕时调用
window.onload =function () {
    // 1. 拿到按钮
    var btn = document.getElementById('btn');
    console.log(btn); /*输出按钮对象*/

    // 2. 监听按钮的点击
    btn.onclick = function () {
        alert('测试！');
    }
};
