function Rect(options) {
    options = options || {};
    // 1. 属性
    this.parentId = options.parentId || 'box';
    this.left = options.left || 100;
    this.top = options.top || 100;
    this.width = options.width || 200;
    this.height = options.height || 100;
    this.bgColor = options.bgColor || '#000';
    this.radius = options.radius;
}
// 矩形的原型对象
Rect.prototype = {
    constructor: Rect,
    // 绘制方法
    render: function () {
        // 1. 创建矩形对象
        var divE = document.createElement('div');
        var fatherE = document.getElementById(this.parentId);
        fatherE.appendChild(divE);

        // 2. 绑定样式属性
        divE.style.width = this.width + 'px';
        divE.style.height = this.height + 'px';
        divE.style.backgroundColor = this.bgColor;
        divE.style.position = 'absolute';
        divE.style.left = this.left + 'px';
        divE.style.top = this.top + 'px';
        divE.style.borderRadius = this.radius;
    }
};
