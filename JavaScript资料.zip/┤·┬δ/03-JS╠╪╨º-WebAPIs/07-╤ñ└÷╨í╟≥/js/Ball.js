class Ball {
    constructor(options) {
        options = options || {};
        // 属性
        this.parentId = options.parentId;
        this.left = options.left;
        this.top = options.top;
        this.bgColor = options.bgColor;
        this.r = 60;

        // 变化的量
        this.dX = _.random(-5, 5);
        this.dY = _.random(-5, 5);
        this.dR = _.random(2, 4);

    }

    // 绘制圆
    render(){
        // 1. 插入元素
        let ballE = document.createElement('div');
        let boxE = document.getElementById(this.parentId);
        boxE.appendChild(ballE);

        // 2. 绑定样式
        ballE.style.position = 'absolute';
        ballE.style.left = this.left + 'px';
        ballE.style.top = this.top + 'px';
        ballE.style.width = this.r + 'px';
        ballE.style.height = this.r + 'px';
        ballE.style.backgroundColor = this.bgColor;
        ballE.style.borderRadius = '50%';
    }

    // 更新位置
    update(){
        this.left += this.dX;
        this.top += this.dY;
        this.r -= this.dR;
        // 判断
        if(this.r <= 0){
            ballArr = _.without(ballArr, this);
        }
    }
}
