(function (w) {
    w.myTool = {
        /**
         * 获取滚动产生的尺寸
         * @returns {{top: number, left: number}}
         */
        scroll(){
            if(window.pageYOffset){
                return {
                    top: w.pageYOffset,
                    left: w.pageXOffset
                }
            }else if(document.compatMode === 'CSS1Compat'){ // 标准模式
                return {
                    top: document.documentElement.scrollTop,
                    left: document.documentElement.scrollLeft
                }
            }
            return {
                top: document.body.scrollTop,
                left: document.body.scrollLeft
            }
        },
        /**
         * 根据id获取标签
         * @param {string}id
         * @returns {any}
         */
        $(id){
            return typeof id === 'string' ? document.getElementById(id): null;
        }
    };
})(window);
