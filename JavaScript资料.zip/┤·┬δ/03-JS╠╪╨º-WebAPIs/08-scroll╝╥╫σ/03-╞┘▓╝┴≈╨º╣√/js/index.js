window.addEventListener('load', function () {
    // 1. 实现瀑布流布局
    waterFull('main', 'box');

    // 2. 监听页面滚动
    window.addEventListener('scroll', function () {
        // 2.1 判断是否具备加载新盒子的条件
        if(isLoadNewBox()){
            setTimeout(()=>{
                // console.log('具备加载条件了!');
                // 2.2 造数据
                let dataJson = [
                    {"src": "img01.jpg"},
                    {"src": "img10.jpg"},
                    {"src": "img02.jpg"},
                    {"src": "img07.jpg"},
                    {"src": "img05.jpg"},
                ];

                // 2.3 创建标签, 装入父盒子
                // <div class="box"><div class="pic"><img src="images/img01.jpg" alt=""></div></div>
                for(let i=0; i<dataJson.length; i++){
                    let newBox = document.createElement('div');
                    newBox.className = 'box';
                    myTool.$('main').appendChild(newBox);

                    let newPic = document.createElement('div');
                    newPic.className = 'pic';
                    newBox.appendChild(newPic);

                    let newImg = document.createElement('img');
                    newImg.src = `images/${dataJson[i].src}`;
                    newPic.appendChild(newImg);
                }

                // 2.4 重新进行瀑布流布局
                waterFull('main', 'box');
            }, 1000);
        }
    });

    // 3. 监听窗口尺寸发生改变
    window.addEventListener('resize', function () {
        waterFull('main', 'box');
    });
});

/**
 * 判断是否具备加载新盒子的条件
 */
function isLoadNewBox() {
    // 1. 取出最后的盒子
    let allBoxE = myTool.$('main').getElementsByClassName('box');
    let lastBox = allBoxE[allBoxE.length - 1];
    // console.log(lastBox);

    // 2. 求出最后盒子自身高度的一半 + offsetTop
    let lastBoxTotal = lastBox.offsetHeight * 0.5 + lastBox.offsetTop;
    // console.log(lastBoxTotal);

    // 3. 求出可视区域的高度
    let screenHeight = document.documentElement.clientHeight || document.body.clientHeight;
    let totalHeight = screenHeight + myTool.scroll().top;

    // 4. 返回
    return totalHeight >= lastBoxTotal;
}


/**
 * 实现瀑布流布局
 * @param {string}fNode
 * @param {string}bNode
 */
function waterFull(fNode, bNode) {
    // 1. 父盒子居中
    // 1.1 获取到标签
    let mainE = myTool.$(fNode);
    let allBoxE = mainE.getElementsByClassName(bNode);
    // 1.2 求出子盒子的宽度
    let boxWidth = allBoxE[0].offsetWidth;
    // 1.3 求出可视区域的宽度
    let screenWidth = document.documentElement.clientWidth || document.body.clientWidth;
    // 1.4 求出列数
    let cols = Math.floor(screenWidth / boxWidth);
    // 1.5 父盒子居中
    mainE.style.width = cols * boxWidth + 'px';
    mainE.style.margin = '0 auto';

    // 2. 定位布局
    let heightArr = [], boxHeight, minHeight, minHeightIndex;
    for(let i=0; i<allBoxE.length; i++){
        // 2.1 求出盒子的高度
        boxHeight = allBoxE[i].offsetHeight;
        // 2.2 判断
       if(i < cols){ // 第一行
           heightArr.push(boxHeight);
           // 清除第一行盒子的定位
           allBoxE[i].style = '';
       }else { // 剩余行
           // 2.3 取出数组中最小值
           minHeight = _.min(heightArr);
           // 2.4 求出最小值在数组中的下标
           minHeightIndex = _.indexOf(heightArr, minHeight);
           // 2.5 剩余盒子的定位
           allBoxE[i].style.position = 'absolute';
           allBoxE[i].style.left = minHeightIndex * boxWidth + 'px';
           allBoxE[i].style.top = minHeight + 'px';
           // 2.6 更新最小高度
           heightArr[minHeightIndex] += boxHeight;
       }
    }
    // console.log(heightArr, minHeight, minHeightIndex);
}
