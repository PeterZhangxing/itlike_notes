(function (w) {
    w.myTool = {
        /**
         * 获取滚动产生的尺寸
         * @returns {{top: number, left: number}}
         */
        scroll(){
            if(window.pageYOffset){
                return {
                    top: w.pageYOffset,
                    left: w.pageXOffset
                }
            }else if(document.compatMode === 'CSS1Compat'){ // 标准模式
                return {
                    top: document.documentElement.scrollTop,
                    left: document.documentElement.scrollLeft
                }
            }
            return {
                top: document.body.scrollTop,
                left: document.body.scrollLeft
            }
        },
        /**
         * 根据id获取标签
         * @param {string}id
         * @returns {any}
         */
        $(id){
            return typeof id === 'string' ? document.getElementById(id): null;
        },
        /**
         * 获取滚动产生的尺寸
         * @returns {{width: number, height: number}}
         */
        client(){
            if(window.innerWidth){
                return {
                    width: w.innerWidth,
                    height: w.innerHeight
                }
            }else if(document.compatMode === 'CSS1Compat'){ // 标准模式
                return {
                    width: document.documentElement.clientWidth,
                    height: document.documentElement.clientHeight
                }
            }
            return {
                width: document.body.clientWidth,
                height: document.body.clientHeight
            }
        }
    };
})(window);
