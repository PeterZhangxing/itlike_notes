<template>
   <div id="home">
      我是首页
   </div>
</template>

<script>
export default {
  name: "Home"
}
</script>

<style scoped>
#home{
  width: 200px;
  height: 500px;
  background-color: red;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>