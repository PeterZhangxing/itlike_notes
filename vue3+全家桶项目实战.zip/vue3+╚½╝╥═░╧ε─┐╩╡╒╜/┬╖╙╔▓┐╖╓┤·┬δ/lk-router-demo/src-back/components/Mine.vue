<template>
  <div id="mine">
    我是我的
  </div>
</template>

<script>
export default {
  name: "Mine"
}
</script>

<style scoped>
#mine{
  width: 200px;
  height: 500px;
  background-color: green;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>