<template>
   <div id="mine_msg">
     我的消息
   </div>
</template>

<script>
export default {
  name: "MineMsg"
}
</script>

<style scoped>
#mine_msg{
  width: 100px;
  height: 200px;
  background-color: purple;
}
</style>