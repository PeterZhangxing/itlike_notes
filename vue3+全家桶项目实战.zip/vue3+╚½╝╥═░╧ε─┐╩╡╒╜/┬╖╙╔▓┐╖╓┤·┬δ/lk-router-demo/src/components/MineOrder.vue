<template>
  <div id="mine_order">
    我的订单
  </div>
</template>

<script>
export default {
  name: "MineOrder"
}
</script>

<style scoped>
#mine_order{
  width: 100px;
  height: 200px;
  background-color: cadetblue;
}
</style>