<template>

</template>

<script>
export default {
  name: "TabBar"
}
</script>

<style scoped>

</style>