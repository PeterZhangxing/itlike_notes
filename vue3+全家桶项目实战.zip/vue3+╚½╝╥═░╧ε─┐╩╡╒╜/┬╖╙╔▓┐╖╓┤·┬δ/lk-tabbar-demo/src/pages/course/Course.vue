<template>
<div id="course">选课</div>
</template>

<script>
export default {
  name: "Course"
}
</script>

<style scoped>
#course{
  width: 100%;
  height: 100%;
  background-color: green;
}
</style>