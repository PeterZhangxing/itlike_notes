<template>
  <div id="friends">朋友圈</div>
</template>

<script>
export default {
  name: "Friends"
}
</script>

<style scoped>
#friends{
  width: 100%;
  height: 100%;
  background-color: purple;
}
</style>