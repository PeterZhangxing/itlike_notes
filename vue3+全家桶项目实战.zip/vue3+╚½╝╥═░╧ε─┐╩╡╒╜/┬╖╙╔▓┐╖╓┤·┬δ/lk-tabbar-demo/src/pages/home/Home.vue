<template>
  <div id="home">首页</div>
</template>

<script>
export default {
  name: "Home"
}
</script>

<style scoped>
#home{
  width: 100%;
  height: 100%;
  background-color: red;
}
</style>