<template>
   <div id="mine">我的</div>
</template>

<script>
export default {
  name: "Mine"
}
</script>

<style scoped>
  #mine{
    width: 100%;
    height: 100%;
    background-color: orange;
  }
</style>