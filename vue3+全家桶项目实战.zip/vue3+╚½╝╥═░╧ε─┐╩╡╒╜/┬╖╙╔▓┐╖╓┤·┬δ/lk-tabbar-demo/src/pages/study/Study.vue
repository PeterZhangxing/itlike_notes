<template>
  <div id="study"></div>
</template>

<script>
export default {
  name: "Study"
}
</script>

<style scoped>
#study{
  width: 100%;
  height: 100%;
  background-color: pink;
}
</style>