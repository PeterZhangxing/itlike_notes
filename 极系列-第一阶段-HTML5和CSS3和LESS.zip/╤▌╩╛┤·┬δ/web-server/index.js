const express = require("express");

let app = express();

app.get("/", function (req, resp) {
    resp.send(`
    <ul>
        <li><a href="/data">点击获取动态数据</a></li>
        <li><a href="/index.html">点击获取静态数据</a></li>
    </ul>
    `)
})

app.use(express.static("public"))

app.get("/data", function (req, resp) {
    resp.send([{
        name: "撩课Sz",
        age: 18,
        position: "嘿嘿嘿"
    }, {
        name: "小撩",
        age: 2,
        position: "吉祥物"
    }])
})

app.listen(5000, function () {
    console.log("web服务器启动成功!", "http://127.0.0.1:5000/")
})