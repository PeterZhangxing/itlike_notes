window.onload = function () {

    let tabs = document.querySelectorAll(".box>.tabbar>ul>li")
    let container_ul = document.querySelector(".box>.container>ul")

    let container = document.getElementsByClassName("container")[0];

    let tl = tabs.length;
    let li_w = container.offsetWidth
    for (let i = 0; i < tl; i++) {
        let tab = tabs[i];
        tab.onmouseover = function () {
            console.log("xxx")
            // 1. 把被鼠标放上来的tab, 添加一个 类名 active
            // 其他的都得移除 active
            tabs.forEach(item=>item.className="");
            tab.className = "active";
            // 移动ul left 值
            // 604
            container_ul.style.left = - i * li_w + "px";
        }
    }


}