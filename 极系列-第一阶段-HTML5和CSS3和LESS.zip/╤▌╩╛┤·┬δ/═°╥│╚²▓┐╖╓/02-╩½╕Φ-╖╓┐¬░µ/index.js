let ps = document.getElementsByTagName("p");
for (let i = 0,len = ps.length; i < len; i++) {
    let p = ps[i];
    p.onclick = function () {
        p.className = p.className === "active" ? "" : "active"
    }
}