export default {
    /**
     * Converts a string to a base 64 string
     * @param str
     */
    encodeBase64: function(str) {
    },
    /**
     * Lookup the mime-type of a filename
     * @param filename
     */
    mimeLookup: function (filename) {
    },
    /**
     * Look up the charset of a mime type
     * @param mime
     */
    charsetLookup: function (mime) {
    },
    /**
     * Gets a source map generator
     */
    getSourceMapGenerator: function getSourceMapGenerator() {
    }
};
