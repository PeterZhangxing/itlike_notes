describe('less.js postProcessor Plugin', function() {
    testLessEqualsInDocument();
});
